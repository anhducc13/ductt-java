package com.shape;

import com.location.Location2D;

public abstract class Shape {

    private String color;
    private boolean filled;
    private Location2D loca;

    // Khởi tạo
    Shape(String color, boolean filled, Location2D loca) {
        this.color = color;
        this.filled = filled;
        this.loca = loca;
    }

    Shape() {
        this("red", true, new Location2D());
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }

    boolean isFilled() {
        return this.filled;
    }

    public Location2D getLoca() {
        return loca;
    }

    public void setLoca(Location2D loca) {
        this.loca = loca;
    }

    @Override
    public abstract String toString();
    
    
    public abstract boolean isDuplicate(Shape s);

}
