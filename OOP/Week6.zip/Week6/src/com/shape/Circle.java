package com.shape;

import com.location.Location2D;

public class Circle extends Shape {

    private double radius;

    private final double PI = 3.14;

    // Khởi tạo
    public Circle(double radius) {
        super();
        this.radius = radius;
    }

    public Circle(double radius, String color, boolean filled, Location2D loca) {
        super(color, filled, loca);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    // Diện tích
    double getArea() {
        return PI * this.radius * this.radius;
    }

    // Chu vi
    double getPerimeter() {
        return 2 * PI * this.radius;
    }

    @Override
    public boolean isDuplicate(Shape s) {
        if (this instanceof Circle && s instanceof Circle) {
            Circle c = (Circle) s;
            return this.radius == c.radius
                    && this.getLoca().isDuplicated(c.getLoca());
            
        } 
        return false;
    }

    @Override
    public String toString() {
        return "This is Circle. Radius: " + this.radius + ". Color: " + this.getColor()
                + ". Filled: " + this.isFilled();
    }
}
