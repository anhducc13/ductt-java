package com.shape;

import com.location.Location2D;
import static java.lang.Math.sqrt;

public class Hexagon extends Shape {

    private double e;

    // Khởi tạo
    public Hexagon(double e) {
        super();
        this.e = e;
    }

    public Hexagon(double e, String color, boolean filled, Location2D loca) {
        super(color, filled, loca);
        this.e = e;
    }

    // Diện tích
    public double getArea() {
        return 6 * e * e * sqrt(3) / 4;
    }

    // Chu vi
    public double getPerimeter() {
        return 6 * e;
    }

    @Override
    public boolean isDuplicate(Shape s) {
        if(this instanceof Hexagon && s instanceof Hexagon) {
            Hexagon h = (Hexagon)s;
            return this.e == h.e && this.getLoca().isDuplicated(h.getLoca());
        }
        return false;
    }
    
    @Override
    public String toString() {
        return "This is Hexagon. 6 Edge: " + this.e
                + ". Color: " + this.getColor() + ". Filled: " + super.isFilled();
    }
}
