package com.shape;

import com.location.Location2D;

public class Square extends Rectangle {

    // Khởi tạo

    public Square(double side) {
        super(side, side);
    }

    public Square(double side, String color, boolean filled, Location2D loca) {
        super(side, side, color, filled, loca);
    }

    // Set side
    public double getSide() {
        return this.getWidth();
    }

    public void setSide(double side) {
        this.setWidth(side);
        this.setLength(side);
    }

    @Override
    public void setWidth(double width) {
        this.setSide(width);
    }

    @Override
    public void setLength(double length) {
        this.setSide(length);
    }
    
    @Override
    public boolean isDuplicate(Shape s) {
        if(this instanceof Square && s instanceof Square) {
            Square sq = (Square)s;
            return this.getSide() == sq.getSide() && this.getLoca().isDuplicated(s.getLoca());
        }
        return false;
    }
    
    @Override
    public String toString() {
        return "This is Square. Side: " + this.getSide() + ". Color: " + this.getColor()
                + ". Filled: " + this.isFilled();
    }
}
