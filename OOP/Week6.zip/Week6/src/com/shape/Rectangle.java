package com.shape;

import com.location.Location2D;

public class Rectangle extends Shape {

    private double width;
    private double length;

    // Khởi tạo
    public Rectangle(double width, double length) {
        super();
        this.width = width;
        this.length = length;
    }

    public Rectangle(double width, double length, String color, boolean filled, Location2D loca) {
        super(color, filled, loca);
        this.width = width;
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    // Diện tích
    public double getArea() {
        return this.width * this.length;
    }

    // Chu vi
    public double getPerimeter() {
        return 2 * (this.width + this.length);
    }
    
    @Override
    public boolean isDuplicate(Shape s) {
        if(this instanceof Rectangle && s instanceof Rectangle) {
            Rectangle r = (Rectangle)s;
            return this.width == r.width && this.length == r.length && 
                    this.getLoca().isDuplicated(r.getLoca());
        }
        return false;
    }

    @Override
    public String toString() {
        return "This is Rectangle. Width: " + this.width + ". Length: " + this.length
                + ". Color: " + this.getColor() + ". Filled: " + this.isFilled();
    }
}
