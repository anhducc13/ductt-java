package com.shape;

import com.location.Location2D;
import static java.lang.Math.*;

public class Triangle extends Shape {

    private double a;
    private double b;
    private double c;

    // Khởi tạo
    public Triangle(double a, double b, double c) {
        super();
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public Triangle(double a, double b, double c, String color, boolean filled, Location2D loca) {
        super(color, filled, loca);
        this.a = a;
        this.b = b;
        this.c = c;
    }

    // Diện tích
    public double getArea() {
        double p = (a + b + c) / 2;
        return sqrt(p * (p - a) * (p - b) * (p - c));
    }

    // Chu vi
    public double getPerimeter() {
        return (a + b + c);
    }
    
    @Override
    public boolean isDuplicate(Shape s) {
        if(this instanceof Triangle && s instanceof Triangle) {
            Triangle t = (Triangle)s;
            return this.a == t.a && this.b == t.b && this.c == t.c && 
                    this.getLoca().isDuplicated(t.getLoca());
        }
        return false;
    }

    @Override
    public String toString() {
        return "This is Triangle. 3 Edge: " + this.a + ", " + this.b + ", " + this.c
                + ". Color: " + this.getColor() + ". Filled: " + super.isFilled();
    }
}
