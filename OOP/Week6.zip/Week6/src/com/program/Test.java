package com.program;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Admin
 */
public class Test {
    
    public static void main(String[] args) {
        JFrame j = new JFrame();
        j.setVisible(true);
        j.setSize(800, 600);
        
    }
}

