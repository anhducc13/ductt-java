package com.program;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class DrawC extends JPanel{
    public void paintComponent(Graphics g) {
     g.setColor(Color.red);
     g.drawRect(400, 0, 300, 300);
     g.drawOval(20, 30, 100, 100); 
  }
    public static void main(String[] args) {
        JFrame j = new JFrame();
        j.setSize(800, 600);
        j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        j.setLocationRelativeTo(null);
        j.setVisible(true);
        
        DrawC d = new DrawC();
        d.setBackground(Color.red);
        j.add(d);
        
        
    }
}
