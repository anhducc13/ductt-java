package com.program;

import com.shape.*;

/**
 *
 * @DucTT
 */
public class Main {

    public static void main(String[] args) {
        Diagram di = new Diagram();
        
        Layer l1 = new Layer("First Layer",true);
        Shape circle1 = new Circle(4.0);
        Shape circle11 = new Circle(4.0);
        Shape rect1 = new Rectangle(3.0, 4.0);
        Shape sq1 = new Square(4.0);
        Shape tri1 = new Triangle(3.0,4.0,5.0);
        l1.addShape(circle1);
        l1.addShape(circle11);
        l1.addShape(rect1);
        l1.addShape(sq1);
        l1.addShape(tri1);
        di.addLayer(l1);

        Layer l2 = new Layer("Second Layer",false);
        Shape circle2 = new Circle(5.0);
        Shape rect2 = new Rectangle(5.0, 4.0);
        Shape sq2 = new Square(5.0);
        Shape tri2 = new Triangle(4.0,3.0,5.0);
        l2.addShape(circle2);
        l2.addShape(rect2);
        l2.addShape(sq2);
        l2.addShape(tri2);
        di.addLayer(l2);
        
        System.out.println("After Insert");
        di.showDiagram();
        
//        System.out.println("\nAfter Delete Duplicate Shape");
//        l1.delDuplicated();
//        di.showDiagram();
        
        System.out.println("\nAfter Delete Circle");
        di.delCircle();
        di.showDiagram();

        System.out.println("\nAfter Move");
        di.standardizeDiagram();
        di.showDiagram();
    }
}
