package com.program;

import com.shape.*;
import java.util.ArrayList;

public class Diagram{

    ArrayList<Layer> diagram = new ArrayList<>();

    // Thêm layer vào diagram nếu visible
    void addLayer(Layer l) {
        if(l.isVisible() && l.layer.size() > 0) {
            diagram.add(l);
        }
    }

    void addLayer(int i, Layer l) {
        if(l.isVisible() && l.layer.size() > 0) {
            diagram.add(i, l);
        }
    }

    Layer getLayer(int i) {
        return diagram.get(i);
    }

    // Xóa tất cả hình tròn trong diagram
    void delCircle() {
        for (int i = 0; i < diagram.size(); i++) {
            diagram.get(i).delCircle();
        }
    }
    
    // Xóa toàn bộ layer
    void clearAll() {
        this.diagram.clear();
    }
    
    // Chuyển về từng loại layer với từng loại hình
    void standardizeDiagram() {
        Layer lCircle = new Layer("Circle Layer", false);
        Layer lRectangle = new Layer("Rectangle Layer", false);
        Layer lTriangle = new Layer("Triangle Layer", false);
        Layer lSquare = new Layer("Square Layer", false);
        Layer lHexagon = new Layer("Hexagon Layer", false);
        
        for(Layer ele : this.diagram) {
            for(Shape s : ele.layer) {
                if(s instanceof Circle) {
                    lCircle.addShape(s);
                    lCircle.setVisible(true);
                } else if(s instanceof Square) {
                    lSquare.addShape(s);
                    lSquare.setVisible(true);
                } else if(s instanceof Rectangle) {
                    lRectangle.addShape(s);
                    lRectangle.setVisible(true);
                } else if(s instanceof Triangle) {
                    lTriangle.addShape(s);
                    lTriangle.setVisible(true);
                } else if(s instanceof Hexagon) {
                    lHexagon.addShape(s);
                    lHexagon.setVisible(true);
                }
            }
        }
        
        this.clearAll();
        this.addLayer(lCircle);
        this.addLayer(lRectangle);
        this.addLayer(lTriangle);
        this.addLayer(lSquare);
        this.addLayer(lHexagon);
    }

    // Vẽ 
    void showDiagram() {
        
        System.out.println("Diagram contains: ");
        if(this.diagram.isEmpty()) {
            System.out.println("EMPTY");
        }
        for (int i = 0; i < diagram.size(); i++) {
            System.out.println(i + 1 + ". " + diagram.get(i).getNameLayer());
            diagram.get(i).showLayer();
        }
    }
}
