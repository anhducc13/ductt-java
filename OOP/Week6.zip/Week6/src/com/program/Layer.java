package com.program;

import com.shape.*;
import java.util.ArrayList;

public class Layer{

    private String nameLayer;
    private boolean visible;
    
    ArrayList<Shape> layer = new ArrayList<>();

    public Layer(String nameLayer, boolean visible) {
        this.nameLayer = nameLayer;
        this.visible = visible;
    }

    public String getNameLayer() {
        return nameLayer;
    }

    public void setNameLayer(String nameLayer) {
        this.nameLayer = nameLayer;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }
    
    // Thêm hình
    void addShape(Shape s) {
        layer.add(s);
    }
    
    // Thêm hình vào vị trí
    void addShape(int i, Shape s) {
        layer.add(i, s);
    }

    Shape getShape(int i) {
        return layer.get(i);
    }

    // Xóa tam giác trong layer
    void delTriangle() {
        for (int i = 0; i < layer.size(); i++) {
            if (layer.get(i) instanceof Triangle) {
                layer.remove(i);
            }
        }
    }

    // Xóa hình tròn trong layer
    void delCircle() {
        for (int i = 0; i < layer.size(); i++) {
            if (layer.get(i) instanceof Circle) {
                layer.remove(i);
            }
        }
    }
    
    // Xóa hình trùng nhau
    void delDuplicated() {
        for(int i = 0; i < layer.size(); i++) {
            for(int j = i+1; j < layer.size(); j++) {
                if(layer.get(i).isDuplicate(layer.get(j))) {
                    layer.remove(j);
                    j--;
                }
            }
        }
    }

    // Vẽ layer
    void showLayer() {
        for (int i = 0; i < layer.size(); i++) {
            System.out.println("\t" + (i + 1) + ". " + layer.get(i).toString());
        }
    }

}
